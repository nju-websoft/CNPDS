"""Constants"""
DEFAULT_ENCODING = 'utf-8'
REQUEST_TIME_OUT = 40

PROVINCE_CURL_JSON_PATH = 'E:\\zhouxiao\\code\\ChinaOpenDataPortal\\src\\main\\python\\metadata\\config\\curl.json'

METADATA_SAVE_PATH = 'E:\\zhouxiao\\code\\ChinaOpenDataPortal\\src\\main\\python\\metadata\\json\\metadata\\'
