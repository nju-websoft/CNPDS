"""Constants"""
DEFAULT_ENCODING = 'utf-8'
REQUEST_TIME_OUT = 5

PROVINCE_CURL_JSON_PATH = 'src\main\python\metadata\config\curl.json'

PROVINCE_LIST = ['shandong', 'jiangsu', 'guangdong', 'hubei', 'hunan']

METADATA_SAVE_PATH = 'src\\main\\python\\metadata\\json\\data\\'