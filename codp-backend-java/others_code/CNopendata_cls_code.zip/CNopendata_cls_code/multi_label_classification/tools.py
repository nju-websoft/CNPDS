#!/usr/bin/env python
# coding:utf-8

import numpy as np
import os
import time
import logging
from logging.handlers import RotatingFileHandler


def get_logger(log_dir: str, back_count: int=32, logger_name: str="pytorch_nlp_tc"):
    """
    get_current_time from time
    Args:
        log_dir: str, log dir of path
        back_count: int, max file-name
        logger_name: str
    Returns:
        logger: class
    """

    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    # 日志文件名,为启动时的日期
    log_file_name = time.strftime("{}-%Y-%m-%d".format(logger_name), time.localtime(time.time())) + ".log"
    log_name_day = os.path.join(log_dir, log_file_name)
    logger_level = logging.DEBUG
    # log目录地址
    if not os.path.exists(log_dir):
        os.mkdir(log_dir)
    # 全局日志格式
    logging.basicConfig(format="%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s", level=logger_level)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    # 定义一个日志记录器
    logger = logging.getLogger("pytorch-textclassification")
    # 文件输出, 定义一个RotatingFileHandler，最多备份32个日志文件，每个日志文件最大32K
    fHandler = RotatingFileHandler(log_name_day, maxBytes=back_count * 1024 * 1024, backupCount=back_count, encoding="utf-8")
    fHandler.setLevel(logger_level)
    fHandler.setFormatter(formatter)
    logger.addHandler(fHandler)
    # 控制台输出
    console = logging.StreamHandler()
    console.setLevel(logger_level)
    logger.addHandler(console)
    return logger