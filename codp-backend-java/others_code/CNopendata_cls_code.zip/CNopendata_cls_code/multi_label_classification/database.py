import pymysql
import json
import random
from sklearn.model_selection import train_test_split


def export_data(db, train_path, dev_path, test_path):
    sql = 'SELECT title, description, standard_industry FROM `metadata` WHERE standard_industry IS NOT NULL'
    cursor = db.cursor()
    cursor.execute(sql)
    data = []
    for result in cursor.fetchall():
        title, description, standard_industry = result
        text = ''
        if title:
            text = title
        if description:
            if text:
                text = text + '。' + description
            else:
                text = description
        data.append({'text': text, 'label': standard_industry.split(',')})
    train_set, dev_set = train_test_split(data, test_size=0.2, random_state=0)

    sql = 'SELECT dataset_id, title, description, standard_industry FROM `metadata` WHERE standard_industry IS NULL'
    cursor.execute(sql)
    test_set = []
    for result in cursor.fetchall():
        dataset_id, title, description, standard_industry = result
        text = ''
        if title:
            text = title
        if description:
            if text:
                text = text + '。' + description
            else:
                text = description
        test_set.append({'text': text, 'label': [], 'dataset_id': dataset_id})
    
    with open(train_path, 'w', encoding='UTF-8') as f:
        for it in train_set:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')
    
    with open(dev_path, 'w', encoding='UTF-8') as f:
        for it in dev_set:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')

    with open(test_path, 'w', encoding='UTF-8') as f:
        for it in test_set:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')


def random_sample_annotated_data(data_path, annotated_path, sample_num):
    data = []
    with open(data_path, 'r', encoding='UTF-8') as f:
        for line in f:
            if line:
                data.append(json.loads(line))
    annotated = random.sample(data, sample_num)
    with open(annotated_path, 'w', encoding='UTF-8') as f:
        for it in annotated:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    train_path = "./data/train.json"
    dev_path = "./data/dev.json"
    test_path = "./data/test.json"
    # db = pymysql.connect(host='114.212.190.189',  # host属性
    #                     port=3306,
    #                     user='qshi',  # 用户名
    #                     password='shiqing123',  # 此处填登录数据库的密码
    #                     db='china_open_data_portal_2023jun',  # 数据库名
    #                     )
    # export_data(db, train_path, dev_path, test_path)

    result_path = "./data/result.txt"
    annotated_path = "./data/annotated.json"
    sample_num = 100
    random_sample_annotated_data(result_path, annotated_path, sample_num)