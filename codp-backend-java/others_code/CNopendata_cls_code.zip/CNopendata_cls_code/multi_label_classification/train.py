# -*- coding: utf-8 -*-


import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from transformers import AdamW
import numpy as np
from data_preprocess import load_json
from bert_multilabel_cls import BertMultiLabelCls
from data_helper import MultiClsDataSet
from sklearn.metrics import accuracy_score
import tools
from sklearn.metrics import classification_report
from transformers import BertTokenizer
from tqdm import tqdm
import json
import os
import warnings
warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2"

train_path = "./data/train.json"
dev_path = "./data/dev.json"
test_path = "./data/test.json"
label2idx_path = "./data/label2idx.json"
save_model_path = "./model/multi_label_cls.pth"
result_path = "./data/result.txt"
log_path = "./log"
label2idx = load_json(label2idx_path)
idx2label = {idx: label for label, idx in label2idx.items()}
class_num = len(label2idx)
device = "cuda" if torch.cuda.is_available() else "cpu"
lr = 2e-5
batch_size = 32
max_len = 256
hidden_size = 768
epochs = 30
early_stop = 5

train_dataset = MultiClsDataSet(train_path, max_len=max_len, label2idx_path=label2idx_path)
dev_dataset = MultiClsDataSet(dev_path, max_len=max_len, label2idx_path=label2idx_path)


train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
dev_dataloader = DataLoader(dev_dataset, batch_size=batch_size, shuffle=False)


logger = tools.get_logger(log_dir=log_path)

def get_acc_score(y_true_tensor, y_pred_tensor):
    y_pred_tensor = (y_pred_tensor.cpu() > 0.5).int().numpy()
    y_true_tensor = y_true_tensor.cpu().numpy()
    return accuracy_score(y_true_tensor, y_pred_tensor)


def train():
    model = BertMultiLabelCls(hidden_size=hidden_size, class_num=class_num)
    model.train()
    model.to(device)

    optimizer = AdamW(model.parameters(), lr=lr)
    criterion = nn.BCELoss()

    dev_best_acc = 0.
    early_stop_count = 0

    for epoch in range(1, epochs):
        if early_stop_count >= early_stop:
            torch.save(model.state_dict(), save_model_path)
            logger.info("Early stop!")
            break
        model.train()

        logger.info(f'Epoch: {epoch}')
        
        # train
        pbar = tqdm(train_dataloader, desc="epoch_{} step".format(epoch))
        for idx, batch in enumerate(pbar):  # step
            optimizer.zero_grad()
            batch = [d.to(device) for d in batch]
            labels = batch[-1]
            logits = model(*batch[:3])
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            pbar.set_description('loss:{:.4f}'.format(loss))
        
        # for i, batch in enumerate(train_dataloader):
        #     optimizer.zero_grad()
        #     batch = [d.to(device) for d in batch]
        #     labels = batch[-1]
        #     logits = model(*batch[:3])
        #     loss = criterion(logits, labels)
        #     loss.backward()
        #     optimizer.step()

        #     if i % 1000 == 0:
        #         acc_score = get_acc_score(labels, logits)
        #         logger.info("Train epoch:{} step:{}  acc: {} loss:{} ".format(epoch, i, acc_score, loss.item()))

        # 验证集合
        dev_loss, dev_acc = dev(model, dev_dataloader, criterion)
        logger.info("Dev epoch:{} acc:{} loss:{}".format(epoch, dev_acc, dev_loss))
        early_stop_count += 1
        if dev_acc > dev_best_acc:
            dev_best_acc = dev_acc
            torch.save(model.state_dict(), save_model_path)
            early_stop_count = 0

    # 测试
    test_acc = test(save_model_path, test_path)
    logger.info("Test acc: {}".format(test_acc))


def dev(model, dataloader, criterion):
    all_loss = []
    model.eval()
    true_labels = []
    pred_labels = []
    with torch.no_grad():
        for i, batch in enumerate(dataloader):
            input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in batch]
            logits = model(input_ids, token_type_ids, attention_mask)
            loss = criterion(logits, labels)
            all_loss.append(loss.item())
            true_labels.append(labels)
            pred_labels.append(logits)
    true_labels = torch.cat(true_labels, dim=0)
    pred_labels = torch.cat(pred_labels, dim=0)
    acc_score = get_acc_score(true_labels, pred_labels)
    return np.mean(all_loss), acc_score


def test(model_path, test_data_path):
    test_dataset = MultiClsDataSet(test_data_path, max_len=max_len, label2idx_path=label2idx_path)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    model = BertMultiLabelCls(hidden_size=hidden_size, class_num=class_num)
    model.load_state_dict(torch.load(model_path))
    model.to(device)
    model.eval()
    true_labels = []
    pred_labels = []
    with torch.no_grad():
        for i, batch in enumerate(test_dataloader):
            input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in batch]
            logits = model(input_ids, token_type_ids, attention_mask)
            true_labels.append(labels)
            pred_labels.append(logits)
    true_labels = torch.cat(true_labels, dim=0)
    pred_labels = torch.cat(pred_labels, dim=0)
    acc_score = get_acc_score(true_labels, pred_labels)
    return acc_score

def predict(texts):
    model = BertMultiLabelCls(hidden_size=hidden_size, class_num=class_num)
    model.load_state_dict(torch.load(save_model_path))
    model.to(device)
    model.eval()
    tokenizer = BertTokenizer.from_pretrained("bert-base-chinese")
    outputs = tokenizer(texts, return_tensors="pt", max_length=max_len,
                        padding=True, truncation=True)
    logits = model(outputs["input_ids"].to(device),
                   outputs["attention_mask"].to(device),
                   outputs["token_type_ids"].to(device))
    logits = logits.cpu().tolist()
    # print(logits)
    result = []
    for sample in logits:
        pred_label = []
        for idx, logit in enumerate(sample):
            if logit > 0.5:
                pred_label.append(idx2label[idx])
        result.append(pred_label)
    return result


def output_predict(model_path, test_data_path, result_path):
    with open(test_data_path, 'r', encoding='UTF-8') as f:
        texts, true_labels, dataset_ids = [], [], []
        for data in f:
            data = json.loads(data)
            text, true_label, dataset_id = data['text'], data['label'], data['dataset_id']
            texts.append(text)
            true_labels.append(true_label)
            dataset_ids.append(dataset_id)
    # for temp in range(len(texts)//100+1):
    #     sub_texts = texts[temp*100: (temp+1)*100]
    #     sub_true_labels = true_labels[temp*100: (temp+1)*100]
    #     pred_labels = predict(sub_texts)
    #     for i in range(len(sub_texts)):
    #         print(f'pred: {pred_labels[i]}, true: {sub_true_labels[i]}, text: {sub_texts[i]}')

    test_dataset = MultiClsDataSet(test_data_path, max_len=max_len, label2idx_path=label2idx_path)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    model = BertMultiLabelCls(hidden_size=hidden_size, class_num=class_num)
    model.load_state_dict(torch.load(model_path))
    model.to(device)
    model.eval()
    pred_labels = []
    with torch.no_grad():
        for i, batch in enumerate(test_dataloader):
            input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in batch]
            logits = model(input_ids, token_type_ids, attention_mask)
            pred_labels.append(logits)
    pred_labels = torch.cat(pred_labels, dim=0)
    y_pred_tensor = (pred_labels.cpu() > 0.5).int().numpy()
    with open(result_path, 'w', encoding='UTF-8') as f:
        for i in range(y_pred_tensor.shape[0]):
            pred_str = []
            for j in range(y_pred_tensor.shape[1]):
                if y_pred_tensor[i][j]:
                    pred_str.append(idx2label[j])
            f.write(json.dumps({'dataset_id': dataset_ids[i], 'pred': pred_str, 'text': texts[i]}, ensure_ascii=False) + '\n')
            # f.write(f'pred: {pred_str}, true: {true_labels[i]}, text: {texts[i]}' + '\n')


def metrics(model_path, test_data_path):
    test_dataset = MultiClsDataSet(test_data_path, max_len=max_len, label2idx_path=label2idx_path)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    model = BertMultiLabelCls(hidden_size=hidden_size, class_num=class_num)
    model.load_state_dict(torch.load(model_path))
    model.to(device)
    model.eval()
    true_labels = []
    pred_labels = []
    with torch.no_grad():
        for i, batch in enumerate(test_dataloader):
            input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in batch]
            logits = model(input_ids, token_type_ids, attention_mask)
            true_labels.append(labels)
            pred_labels.append(logits)
    true_labels = torch.cat(true_labels, dim=0)
    pred_labels = torch.cat(pred_labels, dim=0)
    y_pred_tensor = (pred_labels.cpu() > 0.5).int().numpy()
    y_true_tensor = true_labels.cpu().numpy()
    report = classification_report(y_true_tensor, y_pred_tensor, output_dict=True)
    macro_f1 = report['macro avg']['f1-score']
    micro_f1 = report['micro avg']['f1-score']
    print(f'mirco-F1: {micro_f1:.4}, macro-F1: {macro_f1:.4}')
    report = classification_report(y_true_tensor, y_pred_tensor)
    print(report)


if __name__ == '__main__':
    # train()
    # output_predict(save_model_path, test_path, result_path)
    metrics(save_model_path, dev_path)
