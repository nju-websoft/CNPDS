# 基于bert多标签分类

# 步骤
- 数据样例见data/train.json
- 获得label2idx.json python data_preprocess.py
- 训练 python train.py
- 预测 pyhton predict.py
