import json
import pandas as pd
import pymysql
import numpy as np
from sklearn.metrics import classification_report, precision_score
from constants import (INDUSTRY_CLASSIFICATION_STANDARD_PATH)


def flatten_children_dictionary(children):
    subset = set()
    if children:
        for child in children:
            subset.add(child['name'])
            sub_children = child['children']
            subset.update(flatten_children_dictionary(sub_children))
    return subset


def load_industry_classification_standard():
    with open(INDUSTRY_CLASSIFICATION_STANDARD_PATH, 'r', encoding='UTF-8') as f:  # 国民经济行业分类_2017.json
        json_data = json.load(f)
    industry_classification_standard = {}
    for data in json_data:
        industry_classification_standard[data['name']] = flatten_children_dictionary(data['children'])
    return industry_classification_standard


def load_industry_data(cursor):
    sql = 'SELECT DISTINCT(industry) FROM `metadata`'
    cursor.execute(sql)
    return [x[0].strip() for x in cursor.fetchall() if x[0]]


def load_category_data(cursor):
    sql = 'SELECT DISTINCT(category) FROM `metadata`'
    cursor.execute(sql)
    return [x[0].strip() for x in cursor.fetchall() if x[0]]


def industry_match(target, standard):
    match = set()
    for key, values in standard.items():
        if key in target:
            match.add(key)
        else:
            for v in values:
                if v in target:
                    match.add(key)
    return match


def map_data_to_industry_standard(data, standard):
    industry_match_results = {}
    for industry in data:
        if industry and type(industry) == str:
            match = set()
            for ind in industry.split(','):
                match.update(industry_match(ind, standard))
            industry_match_results[industry] = match
    return industry_match_results


def map_and_update_metadata(db, industry_mapping, category_mapping):
    cursor = db.cursor()
    sql = 'SELECT dataset_id, industry, category FROM `metadata`'
    cursor.execute(sql)
    update_data = []
    for result in cursor.fetchall():
        dataset_id, industry, category = result
        if industry:
            industry = industry.strip()
        if category:
            category = category.strip()
        standard_industry = None
        if industry and industry_mapping[industry]:
            standard_industry = ','.join(industry_mapping[industry])
        elif category and category_mapping[category]:
            standard_industry = ','.join(category_mapping[category])
        if standard_industry:
            update_data.append([standard_industry, dataset_id])
    print(f'update: {len(update_data)}')
    sql = 'UPDATE metadata SET standard_industry = (%s) WHERE dataset_id = (%s)'
    try:
        row = cursor.executemany(sql, update_data)
        db.commit()
        print(f'commit row: {row}')
    except Exception as e:
        db.rollback()
        print(e)


# 字符串匹配，能匹配上的数据作为train data，不能匹配上的数据作为predict data
def run():
    industry_classification_standard = load_industry_classification_standard()
    # mysql连接配置要改一下
    db = pymysql.connect(host='',  # host属性
                         port=3306,
                         user='',  # 用户名
                         password='',  # 此处填登录数据库的密码
                         db='china_open_data_portal_2023jun',  # 数据库名
                         )
    cursor = db.cursor()
    industry_data = load_industry_data(cursor)
    industry_mapping = map_data_to_industry_standard(industry_data, industry_classification_standard)
    category_data = load_category_data(cursor)
    category_mapping = map_data_to_industry_standard(category_data, industry_classification_standard)
    map_and_update_metadata(db=db, industry_mapping=industry_mapping, category_mapping=category_mapping)
    db.close()


if __name__ == '__main__':
    run()